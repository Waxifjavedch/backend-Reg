<!DOCTYPE html>
<html>
<head>
    <title>Backed Laravel Of Our Project</title>
    <link href="https://bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<body>
  
<div class="container">
    @yield('content')
</div>
   
</body>
</html>